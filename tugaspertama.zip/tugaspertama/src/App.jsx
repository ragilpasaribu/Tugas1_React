import myfoto2 from './assets/myfoto2.jpg';

const biodata = {
  id: 1,
  name: "RAGIL SADEWA PASARIBU",
  born: "09-03-2004",
  age: "20",
  hobbies: ["Badminton", "Berenang", "Dance"],
  image: myfoto2,
};

function App() {
  return (
    <div className="sampul">
      <h1>TUGAS 1 KELOMPOK GALAKSI</h1>
      <div className="isi">
        <h2>BIODATA SAYA</h2>
        <img src={biodata.image} alt="fotoku" />
        <h3>Name: {biodata.name}</h3>
        <h3>Born: {biodata.born}</h3>
        <h3>Age: {biodata.age}</h3>
        <div>
          <h3>Hobbies:</h3>
          {biodata.hobbies.map((hobby, index) => (
            <div key={index} className="hobby">
              {hobby}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default App;
